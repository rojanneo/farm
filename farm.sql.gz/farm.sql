-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 14, 2014 at 10:45 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `farm`
--

-- --------------------------------------------------------

--
-- Table structure for table `family`
--

DROP TABLE IF EXISTS `family`;
CREATE TABLE IF NOT EXISTS `family` (
  `family_id` int(11) NOT NULL AUTO_INCREMENT,
  `family_code` varchar(255) NOT NULL,
  `family_created_date` date NOT NULL,
  `family_doe_count` int(11) NOT NULL DEFAULT '0',
  `family_buck_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`family_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `family`
--

INSERT INTO `family` (`family_id`, `family_code`, `family_created_date`, `family_doe_count`, `family_buck_count`) VALUES
(1, 'family_1', '2014-11-14', 3, 1),
(2, 'family_2', '2014-11-14', 3, 1),
(3, 'family_3', '2014-11-14', 3, 1),
(4, 'family_4', '2014-11-14', 3, 1),
(5, 'family_5', '2014-11-14', 3, 1),
(6, 'family_6', '2014-11-14', 3, 1),
(7, 'family_7', '2014-11-14', 3, 1),
(8, 'family_8', '2014-11-14', 3, 1),
(9, 'family_9', '2014-11-14', 3, 1),
(10, 'family_10', '2014-11-14', 3, 1),
(11, 'family_11', '2014-11-14', 3, 1),
(12, 'family_12', '2014-11-14', 3, 1),
(13, 'family_13', '2014-11-14', 3, 1),
(14, 'family_14', '2014-11-14', 3, 1),
(15, 'family_15', '2014-11-14', 3, 1),
(16, 'family_16', '2014-11-14', 3, 1),
(17, 'family_17', '2014-11-14', 3, 1),
(18, 'family_18', '2014-11-14', 3, 1),
(19, 'family_19', '2014-11-14', 3, 1),
(20, 'family_20', '2014-11-14', 3, 1),
(21, 'family_21', '2014-11-14', 3, 1),
(22, 'family_22', '2014-11-14', 3, 1),
(23, 'family_23', '2014-11-14', 3, 1),
(24, 'family_24', '2014-11-14', 3, 1),
(25, 'family_25', '2014-11-14', 3, 1),
(26, 'family_26', '2014-11-14', 3, 1),
(27, 'family_27', '2014-11-14', 3, 1),
(28, 'family_28', '2014-11-14', 3, 1),
(29, 'family_29', '2014-11-14', 3, 1),
(30, 'family_30', '2014-11-14', 3, 1),
(31, 'family_31', '2014-11-14', 3, 1),
(32, 'family_32', '2014-11-14', 3, 1),
(33, 'family_33', '2014-11-14', 3, 1),
(34, 'family_34', '2014-11-14', 3, 1),
(35, 'family_35', '2014-11-14', 3, 1),
(36, 'family_36', '2014-11-14', 3, 1),
(37, 'family_37', '2014-11-14', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `family_to_be`
--

DROP TABLE IF EXISTS `family_to_be`;
CREATE TABLE IF NOT EXISTS `family_to_be` (
  `family_to_be_id` int(11) NOT NULL AUTO_INCREMENT,
  `family_to_be_doe` int(11) NOT NULL,
  `family_to_be_buck` int(11) NOT NULL,
  PRIMARY KEY (`family_to_be_id`),
  KEY `family_to_be_doe` (`family_to_be_doe`,`family_to_be_buck`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `litters`
--

DROP TABLE IF EXISTS `litters`;
CREATE TABLE IF NOT EXISTS `litters` (
  `litter_id` int(11) NOT NULL AUTO_INCREMENT,
  `litter_code` varchar(255) NOT NULL,
  `litter_dob` date NOT NULL,
  `litter_does` int(11) NOT NULL,
  `litter_bucks` int(11) NOT NULL,
  `litter_family` int(11) NOT NULL,
  PRIMARY KEY (`litter_id`),
  KEY `litter_family` (`litter_family`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `rabbits`
--

DROP TABLE IF EXISTS `rabbits`;
CREATE TABLE IF NOT EXISTS `rabbits` (
  `rabbit_id` int(11) NOT NULL AUTO_INCREMENT,
  `rabbit_type` enum('Doe','Buck') NOT NULL,
  `rabbit_litter_id` int(11) NOT NULL,
  `rabbit_family` int(11) NOT NULL,
  `rabbit_code` varchar(255) NOT NULL,
  PRIMARY KEY (`rabbit_id`),
  KEY `rabbit_litter_id` (`rabbit_litter_id`,`rabbit_family`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=146 ;

--
-- Dumping data for table `rabbits`
--

INSERT INTO `rabbits` (`rabbit_id`, `rabbit_type`, `rabbit_litter_id`, `rabbit_family`, `rabbit_code`) VALUES
(1, 'Doe', 0, 1, 'rabbit_1'),
(2, 'Doe', 0, 1, 'rabbit_2'),
(3, 'Doe', 0, 1, 'rabbit_3'),
(4, 'Doe', 0, 2, 'rabbit_4'),
(5, 'Doe', 0, 2, 'rabbit_5'),
(6, 'Doe', 0, 2, 'rabbit_6'),
(7, 'Doe', 0, 3, 'rabbit_7'),
(8, 'Doe', 0, 3, 'rabbit_8'),
(9, 'Doe', 0, 3, 'rabbit_9'),
(10, 'Doe', 0, 4, 'rabbit_10'),
(11, 'Doe', 0, 4, 'rabbit_11'),
(12, 'Doe', 0, 4, 'rabbit_12'),
(13, 'Doe', 0, 5, 'rabbit_13'),
(14, 'Doe', 0, 5, 'rabbit_14'),
(15, 'Doe', 0, 5, 'rabbit_15'),
(16, 'Doe', 0, 6, 'rabbit_16'),
(17, 'Doe', 0, 6, 'rabbit_17'),
(18, 'Doe', 0, 6, 'rabbit_18'),
(19, 'Doe', 0, 7, 'rabbit_19'),
(20, 'Doe', 0, 7, 'rabbit_20'),
(21, 'Doe', 0, 7, 'rabbit_21'),
(22, 'Doe', 0, 8, 'rabbit_22'),
(23, 'Doe', 0, 8, 'rabbit_23'),
(24, 'Doe', 0, 8, 'rabbit_24'),
(25, 'Doe', 0, 9, 'rabbit_25'),
(26, 'Doe', 0, 9, 'rabbit_26'),
(27, 'Doe', 0, 9, 'rabbit_27'),
(28, 'Doe', 0, 10, 'rabbit_28'),
(29, 'Doe', 0, 10, 'rabbit_29'),
(30, 'Doe', 0, 10, 'rabbit_30'),
(31, 'Doe', 0, 11, 'rabbit_31'),
(32, 'Doe', 0, 11, 'rabbit_32'),
(33, 'Doe', 0, 11, 'rabbit_33'),
(34, 'Doe', 0, 12, 'rabbit_34'),
(35, 'Doe', 0, 12, 'rabbit_35'),
(36, 'Doe', 0, 12, 'rabbit_36'),
(37, 'Doe', 0, 13, 'rabbit_37'),
(38, 'Doe', 0, 13, 'rabbit_38'),
(39, 'Doe', 0, 13, 'rabbit_39'),
(40, 'Doe', 0, 14, 'rabbit_40'),
(41, 'Doe', 0, 14, 'rabbit_41'),
(42, 'Doe', 0, 14, 'rabbit_42'),
(43, 'Doe', 0, 15, 'rabbit_43'),
(44, 'Doe', 0, 15, 'rabbit_44'),
(45, 'Doe', 0, 15, 'rabbit_45'),
(46, 'Doe', 0, 16, 'rabbit_46'),
(47, 'Doe', 0, 16, 'rabbit_47'),
(48, 'Doe', 0, 16, 'rabbit_48'),
(49, 'Doe', 0, 17, 'rabbit_49'),
(50, 'Doe', 0, 17, 'rabbit_50'),
(51, 'Doe', 0, 17, 'rabbit_51'),
(52, 'Doe', 0, 18, 'rabbit_52'),
(53, 'Doe', 0, 18, 'rabbit_53'),
(54, 'Doe', 0, 18, 'rabbit_54'),
(55, 'Doe', 0, 19, 'rabbit_55'),
(56, 'Doe', 0, 19, 'rabbit_56'),
(57, 'Doe', 0, 19, 'rabbit_57'),
(58, 'Doe', 0, 20, 'rabbit_58'),
(59, 'Doe', 0, 20, 'rabbit_59'),
(60, 'Doe', 0, 20, 'rabbit_60'),
(61, 'Doe', 0, 21, 'rabbit_61'),
(62, 'Doe', 0, 21, 'rabbit_62'),
(63, 'Doe', 0, 21, 'rabbit_63'),
(64, 'Doe', 0, 22, 'rabbit_64'),
(65, 'Doe', 0, 22, 'rabbit_65'),
(66, 'Doe', 0, 22, 'rabbit_66'),
(67, 'Doe', 0, 23, 'rabbit_67'),
(68, 'Doe', 0, 23, 'rabbit_68'),
(69, 'Doe', 0, 23, 'rabbit_69'),
(70, 'Doe', 0, 24, 'rabbit_70'),
(71, 'Doe', 0, 24, 'rabbit_71'),
(72, 'Doe', 0, 24, 'rabbit_72'),
(73, 'Doe', 0, 25, 'rabbit_73'),
(74, 'Doe', 0, 25, 'rabbit_74'),
(75, 'Doe', 0, 25, 'rabbit_75'),
(76, 'Doe', 0, 26, 'rabbit_76'),
(77, 'Doe', 0, 26, 'rabbit_77'),
(78, 'Doe', 0, 26, 'rabbit_78'),
(79, 'Doe', 0, 27, 'rabbit_79'),
(80, 'Doe', 0, 27, 'rabbit_80'),
(81, 'Doe', 0, 27, 'rabbit_81'),
(82, 'Doe', 0, 28, 'rabbit_82'),
(83, 'Doe', 0, 28, 'rabbit_83'),
(84, 'Doe', 0, 28, 'rabbit_84'),
(85, 'Doe', 0, 29, 'rabbit_85'),
(86, 'Doe', 0, 29, 'rabbit_86'),
(87, 'Doe', 0, 29, 'rabbit_87'),
(88, 'Doe', 0, 30, 'rabbit_88'),
(89, 'Doe', 0, 30, 'rabbit_89'),
(90, 'Doe', 0, 30, 'rabbit_90'),
(91, 'Doe', 0, 31, 'rabbit_91'),
(92, 'Doe', 0, 31, 'rabbit_92'),
(93, 'Doe', 0, 31, 'rabbit_93'),
(94, 'Doe', 0, 32, 'rabbit_94'),
(95, 'Doe', 0, 32, 'rabbit_95'),
(96, 'Doe', 0, 32, 'rabbit_96'),
(97, 'Doe', 0, 33, 'rabbit_97'),
(98, 'Doe', 0, 33, 'rabbit_98'),
(99, 'Doe', 0, 33, 'rabbit_99'),
(100, 'Doe', 0, 34, 'rabbit_100'),
(101, 'Doe', 0, 34, 'rabbit_101'),
(102, 'Doe', 0, 34, 'rabbit_102'),
(103, 'Doe', 0, 35, 'rabbit_103'),
(104, 'Doe', 0, 35, 'rabbit_104'),
(105, 'Doe', 0, 35, 'rabbit_105'),
(106, 'Buck', 0, 1, 'rabbit_106'),
(107, 'Buck', 0, 2, 'rabbit_107'),
(108, 'Buck', 0, 3, 'rabbit_108'),
(109, 'Buck', 0, 4, 'rabbit_109'),
(110, 'Buck', 0, 5, 'rabbit_110'),
(111, 'Buck', 0, 6, 'rabbit_111'),
(112, 'Buck', 0, 7, 'rabbit_112'),
(113, 'Buck', 0, 8, 'rabbit_113'),
(114, 'Buck', 0, 9, 'rabbit_114'),
(115, 'Buck', 0, 10, 'rabbit_115'),
(116, 'Buck', 0, 11, 'rabbit_116'),
(117, 'Buck', 0, 12, 'rabbit_117'),
(118, 'Buck', 0, 13, 'rabbit_118'),
(119, 'Buck', 0, 14, 'rabbit_119'),
(120, 'Buck', 0, 15, 'rabbit_120'),
(121, 'Buck', 0, 16, 'rabbit_121'),
(122, 'Buck', 0, 17, 'rabbit_122'),
(123, 'Buck', 0, 18, 'rabbit_123'),
(124, 'Buck', 0, 19, 'rabbit_124'),
(125, 'Buck', 0, 20, 'rabbit_125'),
(126, 'Buck', 0, 21, 'rabbit_126'),
(127, 'Buck', 0, 22, 'rabbit_127'),
(128, 'Buck', 0, 23, 'rabbit_128'),
(129, 'Buck', 0, 24, 'rabbit_129'),
(130, 'Buck', 0, 25, 'rabbit_130'),
(131, 'Buck', 0, 26, 'rabbit_131'),
(132, 'Buck', 0, 27, 'rabbit_132'),
(133, 'Buck', 0, 28, 'rabbit_133'),
(134, 'Buck', 0, 29, 'rabbit_134'),
(135, 'Buck', 0, 30, 'rabbit_135'),
(136, 'Buck', 0, 31, 'rabbit_136'),
(137, 'Buck', 0, 32, 'rabbit_137'),
(138, 'Buck', 0, 33, 'rabbit_138'),
(139, 'Buck', 0, 34, 'rabbit_139'),
(140, 'Buck', 0, 35, 'rabbit_140'),
(141, 'Buck', 0, 36, 'rabbit_141'),
(142, 'Buck', 0, 37, 'rabbit_142'),
(143, 'Doe', 0, 36, 'rabbit_143'),
(144, 'Doe', 0, 36, 'rabbit_144'),
(145, 'Doe', 0, 36, 'rabbit_145');
SET FOREIGN_KEY_CHECKS=1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
